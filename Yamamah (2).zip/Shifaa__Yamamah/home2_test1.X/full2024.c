/*
 * File:   full_2024.c
 * Author: hp
 *
 * Created on October 28, 2024, 5:51 PM
 */

// PIC18F4620 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1H
#pragma config OSC = RCIO6      // Oscillator Selection bits (External RC oscillator, port function on RA6)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit (Oscillator Switchover mode disabled)

// CONFIG2L
#pragma config PWRT = OFF       // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = SBORDIS  // Brown-out Reset Enable bits (Brown-out Reset enabled in hardware only (SBOREN is disabled))
#pragma config BORV = 3         // Brown Out Reset Voltage bits (Minimum setting)

// CONFIG2H
#pragma config WDT = ON         // Watchdog Timer Enable bit (WDT enabled)
#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)

// CONFIG3H
#pragma config CCP2MX = PORTC   // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
#pragma config PBADEN = ON      // PORTB A/D Enable bit (PORTB<4:0> pins are configured as analog input channels on Reset)
#pragma config LPT1OSC = OFF    // Low-Power Timer1 Oscillator Enable bit (Timer1 configured for higher power operation)
#pragma config MCLRE = ON       // MCLR Pin Enable bit (MCLR pin enabled; RE3 input pin disabled)

// CONFIG4L
#pragma config STVREN = ON      // Stack Full/Underflow Reset Enable bit (Stack full/underflow will cause Reset)
#pragma config LVP = ON         // Single-Supply ICSP Enable bit (Single-Supply ICSP enabled)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection bit (Block 0 (000800-003FFFh) not code-protected)
#pragma config CP1 = OFF        // Code Protection bit (Block 1 (004000-007FFFh) not code-protected)
#pragma config CP2 = OFF        // Code Protection bit (Block 2 (008000-00BFFFh) not code-protected)
#pragma config CP3 = OFF        // Code Protection bit (Block 3 (00C000-00FFFFh) not code-protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) not code-protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM not code-protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection bit (Block 0 (000800-003FFFh) not write-protected)
#pragma config WRT1 = OFF       // Write Protection bit (Block 1 (004000-007FFFh) not write-protected)
#pragma config WRT2 = OFF       // Write Protection bit (Block 2 (008000-00BFFFh) not write-protected)
#pragma config WRT3 = OFF       // Write Protection bit (Block 3 (00C000-00FFFFh) not write-protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot Block (000000-0007FFh) not write-protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM not write-protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection bit (Block 0 (000800-003FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection bit (Block 1 (004000-007FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection bit (Block 2 (008000-00BFFFh) not protected from table reads executed in other blocks)
#pragma config EBTR3 = OFF      // Table Read Protection bit (Block 3 (00C000-00FFFFh) not protected from table reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF      // Boot Block Table Read Protection bit (Boot Block (000000-0007FFh) not protected from table reads executed in other blocks)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.
#include <xc.h>
#include <stdio.h>
#include <string.h>
#include "my_ser.h"
#include "my_adc.h"
#include "lcd_x8.h"
#include "my_pwm.h"
#define _XTAL_FREQ 4000000 
#define WINTER_T 40
#define SUMMER_T 60
////////////////////////////////////////////////////////////
void initPorts(void);
void setupInterpurts(void);
void setup_compare(void);

void OffMode(void);
void CoolMode(void);
void heatMode(void);
void autoHC(void);

void printingOnScreen(void);
void processSerialCommand(char receivedChar); // ser command
/////////////////////////////////////////////////////////////
typedef enum { OFF, COOL, HEAT, AUTO_HC} Mode;
Mode current_mode= OFF;
int mode_counter=0;
int Hs = 0;
char Buffer[32];
char buffer[20]; 
int raw_value;
float AI0;
float AI1;
float AI2;

float OT;
float SP;
float RT;

#define COOLER_INCREMENT 5
#define HEAT_INCREMENT 5


 unsigned char percent_heat = 0;  
 unsigned char Heat_Counter= 0; 
 

 unsigned char percent_cooler = 0;  
 unsigned char cooler_Counter= 0; 
 
unsigned int sendDataFlag = 0;  // Flag to send data
unsigned int systemOffFlag = 0; // Flag for system OFF


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Heater_Off(void) { PORTCbits.RC5 = 0; }
void Heater_On(void) { PORTCbits.RC5 = 1; }
void Cooler_Off(void) { PORTCbits.RC2 = 0; }
void Cooler_On(void) { PORTCbits.RC2 = 1; }

 void initPorts(void) {
    ADCON0 = 0;
    ADCON1 = 0b00001100; 
    LATA = LATB = LATC = LATD = LATE = 0;
     TRISA = 0xFF; 
    TRISB = 0xFF;
    TRISC = 0x80; 
    TRISD = 0; 
    TRISE = 0; 
    setupSerial(); 
}
void setupInterpurts(void) {
    // Setting up interrupts INT0, INT1, INT2 to change modes and control Hs
    INTCON2bits.INTEDG0 = 1;  // Interrupt on rising edge of INT0 (to change mode)
    INTCONbits.INT0IE = 1;     // Enable INT0 interrupt
    INTCONbits.INT0IF = 0;     // Clear INT0 interrupt flag

    INTCON2bits.INTEDG1 = 1;   // Interrupt on rising edge of INT1 (increase Hs)
    INTCON3bits.INT1IE = 1;    // Enable INT1 interrupt
    INTCON3bits.INT1IF = 0;    // Clear INT1 interrupt flag

    INTCON2bits.INTEDG2 = 1;   // Interrupt on rising edge of INT2 (decrease Hs)
    INTCON3bits.INT2IE = 1;    // Enable INT2 interrupt
    INTCON3bits.INT2IF = 0;    // Clear INT2 interrupt flag

    // Initialize Timer3 for PWM control of the heater
     T3CON = 0x01; // Prescaler ?????
    TMR3H = 0x9E; // ????? ????? ?????? ????????
    TMR3L = 0x58;
    PIR2bits.TMR3IF = 0;
    PIE2bits.TMR3IE = 1;
    T3CONbits.TMR3ON = 1;
    
    PIE1bits.RCIE = 1;         // Enable UART receive interrupt
    PIR1bits.RCIF = 0;         // Clear UART receive interrupt flag

    INTCONbits.GIE = 1;        // Enable global interrupts
    INTCONbits.PEIE = 1;       // Enable peripheral interrupts
}
#define STARTVALUE  3036  // To set Timer0 frequency

unsigned int RPS_count = 0;

void initTimers01(void) {
    T0CON = 0;  // Initialize Timer0
    T0CONbits.T0PS0 = 1;  // Prescaler = 16
    T0CONbits.T0PS1 = 1;
    T0CONbits.T0PS2 = 0;
    TMR0H = (unsigned char) ((STARTVALUE >> 8) & 0x00FF);
    TMR0L = (unsigned char) (STARTVALUE & 0x00FF);

    T1CONbits.TMR1CS = 1;  // Initialize Timer1 to measure fan speed
    T1CONbits.T1CKPS1 = 0;
    T1CONbits.T1CKPS0 = 0;

    TMR1H = 0;
    TMR1L = 0;
    INTCONbits.GIE = 1;  // Enable global interrupts
    INTCONbits.T0IE = 1;  // Enable Timer0 interrupt
    T1CONbits.TMR1ON = 1;  // Start Timer1
    T0CONbits.TMR0ON = 1;  // Start Timer0
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void __interrupt(high_priority) highIsr(void) {
    static unsigned char pwmCounter = 0;
    
    // Serial data reception interrupt
        if (PIR1bits.RCIF) {  // Data from Serial
            char receivedChar = read_byte_no_lib();  // Read received character
            processSerialCommand(receivedChar);  // Process command
            PIR1bits.RCIF = 0;  // Clear RC interrupt flag
        } 
          
    
    
    
    
    // Timer0 interrupt to calculate fan speed (RPS)
    if (INTCONbits.T0IF) {
        RPS_count = ((unsigned int) TMR1H << 8) | TMR1L;
        TMR0H = (unsigned char) ((STARTVALUE >> 8) & 0x00FF);
        TMR0L = (unsigned char) (STARTVALUE & 0x00FF);
        TMR1H = 0;
        TMR1L = 0;
        INTCONbits.T0IF = 0;  // Clear Timer0 interrupt flag
    }

       
    
    
    
    // INT0 interrupt to change system modes
    if (INTCONbits.INT0IF) {
        __delay_ms(300);  // Delay to avoid rapid switching
        mode_counter++;

        switch (mode_counter) {
            case 0:
                current_mode = OFF;
                break;
            case 1:
                current_mode = HEAT ;
                break;
            case 2:
                current_mode = COOL;
                break;
            case 3:
                current_mode = AUTO_HC;
                mode_counter = 0;
                break;
            default:
                mode_counter = 0;
                break;
        }
        INTCONbits.INT0IF = 0;  // Clear INT0 interrupt flag
    }

    // INT2 interrupt to increase values
    if (INTCON3bits.INT2IF) {  
        __delay_ms(250);
        if (current_mode == COOL && cooler_Counter < 20) {  // Increase cooling
            cooler_Counter++;
            percent_cooler = cooler_Counter * 5;
            set_pwm1_percent(percent_cooler);
           
        } else if (current_mode == HEAT && Heat_Counter < 20) {  // Increase heating
            Heat_Counter++;
            percent_heat = Heat_Counter * 5;
           
        } else if (current_mode == AUTO_HC && Hs < 3) {  // Increase Hs in Auto HC mode
            Hs++;
      
        }
        INTCON3bits.INT2IF = 0;  // Clear INT2 interrupt flag
    }

    // INT1 interrupt to decrease values
    if (INTCON3bits.INT1IF) {  
        __delay_ms(250);
        if (current_mode == COOL && cooler_Counter > 0) {  // Decrease cooling
            cooler_Counter--;
            percent_cooler = cooler_Counter * 5;
            set_pwm1_percent(percent_cooler);
          
        } else if (current_mode == HEAT && Heat_Counter > 0) {  // Decrease heating
            Heat_Counter--;
            percent_heat = Heat_Counter * 5;
            
        } else if (current_mode == AUTO_HC && Hs > 0) {  // Decrease Hs in Auto HC mode
            Hs--;
           
        }
        INTCON3bits.INT1IF = 0;  // Clear INT1 interrupt flag
    }

    // Timer3 interrupt to control PWM for the heater in HEAT mode
     if (PIR2bits.TMR3IF) {  
        PIR2bits.TMR3IF = 0;  // ??? ??? ???????? Timer3
        pwmCounter++;         // ????? ???? PWM

        // ????? ?????? ?????? ????? ??? ?????? ??????? ???????
        if (pwmCounter < Heat_Counter) {  // ????? ?????? ??? ???? ??? PWM
            Heater_On();
        } else {
            Heater_Off();
        }

        // ????? ????? ?????? ??? ????? ??????
        if (pwmCounter >= 20) {  // ????? ????? ?????? ??? ???? ?????
            pwmCounter = 0;
        }
    }

   
}



void OffMode(void) {
    lcd_gotoxy(1, 4);
    sprintf(Buffer, "MD:OFF          ");
    lcd_puts(Buffer);
    PORTCbits.RC2 = 0;
    PORTCbits.RC5 = 0;
    CCP1CON = 0x00;
    Heater_Off();
    Cooler_Off();
    
    

    // Display heater and cooler status
    lcd_gotoxy(14, 1);
    sprintf(Buffer, "H C");
    lcd_puts(Buffer);

    lcd_gotoxy(14, 2);
    sprintf(Buffer, "N N");  
    lcd_puts(Buffer);
    
lcd_gotoxy(1, 3);
    sprintf(Buffer, "OT:%2.1fC         ", OT);  
    lcd_puts(Buffer);
    
}

void CoolMode(void) {
    lcd_gotoxy(1, 4);
    sprintf(Buffer, "MD:CooL          ");
    lcd_puts(Buffer);
    PORTCbits.RC2 = 0;
           PORTCbits.RC5 = 0;
           CCP1CON=0x00;
    Heater_Off();
    Cooler_On();
    init_pwm1();
    percent_cooler = cooler_Counter * COOLER_INCREMENT;
    set_pwm1_percent(percent_cooler);
    
    lcd_gotoxy(14, 1);
    sprintf(Buffer, "H C");
    lcd_puts(Buffer);

    lcd_gotoxy(14, 2);
    sprintf(Buffer, "N Y");  
    lcd_puts(Buffer);

     lcd_gotoxy(1, 3);
     sprintf(Buffer, "OT:%2.1fC         ", OT);  
     lcd_puts(Buffer);
     
    lcd_gotoxy(1, 3);
    sprintf(Buffer, "OT:%2.1fC  C:%d%%", OT,  percent_cooler); 
    lcd_puts(Buffer);
}
void setupTimer3(void) {
    T3CON = 0x01; // Prescaler ?????
    TMR3H = 0x9E; // ????? ????? ?????? ????????
    TMR3L = 0x58;
    PIR2bits.TMR3IF = 0;
    PIE2bits.TMR3IE = 1;
    T3CONbits.TMR3ON = 1;
}

void heatMode(void) {
      Heat_Counter = percent_heat / 5;  // ????? ???? Heat_Counter ????? ??? ?????? ????????
    setupTimer3(); // ????? Timer3 ????? ?????? ????
    lcd_gotoxy(1, 4);
    sprintf(Buffer, "MD:Heat         ");
    lcd_puts(Buffer);
    Cooler_Off();
           PORTCbits.RC2 = 0;
           PORTCbits.RC5 = 0;
           CCP1CON=0x00;
    
    

    TMR3H = 0;
    TMR3L = 0;
    PIE2bits.TMR3IE = 1;  
    PIR2bits.TMR3IF = 0;  
    T3CONbits.TMR3ON = 1;  

    
    lcd_gotoxy(14, 1);
    sprintf(Buffer, "H C");
    lcd_puts(Buffer);

    lcd_gotoxy(14, 2);
    sprintf(Buffer, "Y N");
    lcd_puts(Buffer);
     lcd_gotoxy(1, 3);
     sprintf(Buffer, "OT:%2.1fC         ", OT);  
     lcd_puts(Buffer);
    
    lcd_gotoxy(1, 3);
    sprintf(Buffer, "OT:%2.1fC  H:%d%%", OT, percent_heat);  
    lcd_puts(Buffer);
}
void autoHC(void) {
     lcd_gotoxy(1, 4);
    sprintf(Buffer, "MD:AutoHC HS:%d", Hs); 
    lcd_puts(Buffer);
    PORTCbits.RC2 = 0;
    PORTCbits.RC5 = 0;
    CCP1CON = 0x00;
    Heater_Off();
    Cooler_Off();
    
           
    float coolError = RT - SP;
    float heatError = SP - RT;
    char heaterStatus = 'N', coolerStatus = 'N';

    if (OT > SUMMER_T) { 
        if (coolError > 0) {
            Cooler_On();
            float pwmValue = coolError * 10;

            if (pwmValue < 25.0) pwmValue = 25.0;
            if (pwmValue > 100.0) pwmValue = 100.0;

            set_pwm1_percent(pwmValue);
            T3CONbits.TMR3ON = 0;       // ???? ?? ????? Timer3
        PIE2bits.TMR3IE = 0;        // ????? ?????? Timer3
        CCP1CON = 0x00;             // ????? ????? PWM ??? RC5
        Heater_Off();  
            
            coolerStatus = 'Y';
        } 
        else if (RT < SP - Hs) {
            set_pwm1_percent(0.0);
            Heater_On();
            set_pwm2_percent(50.0);
            coolerStatus = 'N';
            heaterStatus = 'Y';
        } 
        else {
            Cooler_Off();
            T3CONbits.TMR3ON = 0;       // ???? ?? ????? Timer3
        PIE2bits.TMR3IE = 0;        // ????? ?????? Timer3
        CCP1CON = 0x00;             // ????? ????? PWM ??? RC5
        Heater_Off();  
        }
    } 
    else if (OT < WINTER_T) { 
        if (heatError > 0) {
            Cooler_Off();
            unsigned char percentHeatCounter = heatError * 2;

            if (percentHeatCounter > 20) percentHeatCounter = 20;
            if (percentHeatCounter < 10) percentHeatCounter = 10;

            TMR3H = 0;
            TMR3L = 0;
            PIE2bits.TMR3IE = 1;
            PIR2bits.TMR3IF = 0;
            T3CONbits.TMR3ON = 1;

            Heater_On();
            heaterStatus = 'Y';
        } 
        else if (RT > SP + Hs) {
            T3CONbits.TMR3ON = 0;       // ???? ?? ????? Timer3
        PIE2bits.TMR3IE = 0;        // ????? ?????? Timer3
        CCP1CON = 0x00;             // ????? ????? PWM ??? RC5
        Heater_Off();  
        }
    } 
    else {  
        Cooler_Off();
        T3CONbits.TMR3ON = 0;       // ???? ?? ????? Timer3
        PIE2bits.TMR3IE = 0;        // ????? ?????? Timer3
        CCP1CON = 0x00;             // ????? ????? PWM ??? RC5
        Heater_Off();  
    }

 
    lcd_gotoxy(14, 1);
    sprintf(Buffer, "H C");
    lcd_puts(Buffer);

    lcd_gotoxy(14, 2);
    sprintf(Buffer, "%c %c", heaterStatus, coolerStatus);  
    lcd_puts(Buffer);

     float fanSpeedRPS = RPS_count / 7.0;  
     lcd_gotoxy(1, 3);
     sprintf(Buffer, "OT:%2.1fC         ", OT);  
    lcd_puts(Buffer);
    
    lcd_gotoxy(1, 3);
    sprintf(Buffer, "OT:%2.1fC R:%4.1f", OT, fanSpeedRPS);  
    lcd_puts(Buffer);
}


void printingOnScreen(void){
    // Read raw ADC values
    
    AI0 = read_adc_raw_no_lib(0);  // Set Point
    AI1 = read_adc_raw_no_lib(1);  // Outside Temperature
    AI2 = read_adc_raw_no_lib(2);  // Room Temperature


    SP=(AI0*5.0*100.0)/1023.0/5.0;
    RT=(AI2*100.0*5.0)/1023.0;
    OT=(AI1 * 100.0) / 1023.0;       
                  
    lcd_gotoxy(1, 1);
    sprintf(Buffer, "RT: %4.1fC ",RT); //Room Temperature
    lcd_puts(Buffer);

    lcd_gotoxy(1, 2);
    sprintf(Buffer, "SP: %4.1fC ",SP);  // Set Point
    lcd_puts(Buffer);

    
   
}



void processSerialCommand(char receivedChar) {
    
        if (receivedChar == 'M') {
            send_string_no_lib((unsigned char *)"Command 'M' received, sending data...\r\n");
            sendDataFlag = 1;        
         }
        
        else if (receivedChar == 'S') {
            send_string_no_lib((unsigned char *)"Command 'S' received, turning system off...\r\n");
            systemOffFlag = 1;
        } 
    
        else {
           
            send_string_no_lib((unsigned char *)"Unknown command received\r\n");
        }

    
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void main(void) {
    initPorts();
    setupSerial();
    send_string_no_lib((unsigned char *)"start....\r\n");

    setupInterpurts();
    lcd_init();
    init_adc_no_lib();

    current_mode = OFF;
    unsigned char rb3_flag = 0;

    while (1) {
        CLRWDT();
        __delay_ms(250);
         PORTCbits.RC2 = 0;
           PORTCbits.RC5 = 0;
           CCP1CON=0x00;
        if (PORTBbits.RB3 == 0 && rb3_flag == 0) {
            current_mode = OFF;
            rb3_flag = 1; 
            send_string_no_lib((unsigned char *)"Switched to OFF mode.\r\n");
        }
        if (PORTBbits.RB3 == 1) {
            rb3_flag = 0;
        }

        // Reset heater and cooler whenever switching modes, except for HEAT and COOL
        if (current_mode != HEAT) {
            Heater_Off();
        }
        if (current_mode != COOL) {
            Cooler_Off();
        }

        
         
         if (sendDataFlag) {
            sprintf(buffer, "RT: %.1fC\r\n", RT);
            send_string_no_lib((unsigned char *)buffer);

            sprintf(buffer, "OT: %.1fC\r\n", OT);
            send_string_no_lib((unsigned char *)buffer);

            sprintf(buffer, "SP: %.1fC\r\n", SP);
            send_string_no_lib((unsigned char *)buffer);

            sprintf(buffer, "Cooler: %s\r\n", PORTCbits.RC2 ? "ON" : "OFF");
            send_string_no_lib((unsigned char *)buffer);

            sprintf(buffer, "Heater: %s\r\n", PORTCbits.RC5 ? "ON" : "OFF");
            send_string_no_lib((unsigned char *)buffer);

            sprintf(buffer, "Cooling %%: %d%%\r\n", percent_cooler);
            send_string_no_lib((unsigned char *)buffer);

            sprintf(buffer, "Heating %%: %d%%\r\n", percent_heat);
            send_string_no_lib((unsigned char *)buffer);

            sendDataFlag = 0;
        }
        
        if (systemOffFlag) {
            current_mode = OFF;
            systemOffFlag = 0; 
        }
           
           
           
           
           
           
           
           
           
        switch (current_mode) {
        case OFF:
            T3CONbits.TMR3ON = 0;       // ???? ?? ????? Timer3
            PIE2bits.TMR3IE = 0;        // ????? ?????? Timer3
            CCP1CON = 0x00;             // ????? ????? PWM ??? RC5
            Heater_Off();               // ???? ?? ????? ??????
            OffMode();
            break;
        
        case COOL:
            T3CONbits.TMR3ON = 0;       // ???? ?? ????? Timer3
            PIE2bits.TMR3IE = 0;        // ????? ?????? Timer3
            CCP1CON = 0x00;             // ????? ????? PWM ??? RC5
            Heater_Off();               // ???? ?? ????? ??????
            CoolMode();
            break;
        
        case HEAT:
            heatMode();                 // ?? ??? HEAT? ??? ????? ??????
            break;
        
        case AUTO_HC:             // ???? ?? ????? ??????
            autoHC();
            break;
        
       default:
            break;
      }
        
       
       
        printingOnScreen();
    }
}