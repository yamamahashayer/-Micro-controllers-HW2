#include "my_pwm.h"

// See chapter 15 page 141 (PWM mode = 11xx)
void init_pwm1(void) // 10-bit accuracy for CCP1 (RC2)
{
    PR2 = 255; // Set period for 10-bit accuracy
    T2CON = 0; // Clear Timer2 Control Register
    CCP1CON = 0x0C; // Select PWM mode for CCP1
    T2CONbits.TMR2ON = 1; // Turn Timer2 on
    TRISCbits.RC2 = 0; // Set RC2 as output for CCP1
}

void init_pwm2(void) // 10-bit accuracy for CCP2 (RC5)
{
    PR2 = 255; // Configure for 10-bit resolution
    T2CON = 0; // Clear Timer 2 control register
    CCP2CON = 0x0C; // Set CCP2 to PWM mode
    TRISCbits.RC5 = 0; // Set RC5 as output for heating
   // T2CONbits.TMR2ON = 1; // Turn Timer 2 on
}

void set_pwm1_raw(unsigned int raw_value) // raw value 0 -- 1023 corresponds to 0--100%
{
    CCPR1L = (raw_value >> 2) & 0x00FF; // Load the upper 8 bits in CCPR1
    CCP1CONbits.DC1B = raw_value & 0x0003; // First two bits in bits 4, 5 of CCP1CON
}

void set_pwm1_percent(float value) // value 0--100%, corresponds to 0--1023
{
    float tmp = value * 1023.0 / 100.0; // Scale 0--100 to 0--1023
    int raw_val = (int)(tmp + 0.5); // For rounding
    if (raw_val > 1023) raw_val = 1023; // Do not exceed max value
    set_pwm1_raw(raw_val);
}

void set_pwm1_voltage(float value) // value 0--5V, corresponds to 0--1023
{
    float tmp = value * 1023.0 / 5.0; // Scale 0--5 to 0--1023
    int raw_val = (int)(tmp + 0.5); // For rounding
    if (raw_val > 1023) raw_val = 1023; // Do not exceed max value
    set_pwm1_raw(raw_val);
}

// Technically this function replaces the previous 2
void set_pwm1_general(float value, float min, float max) // value range from min to max
{
    float tmp = (value - min) * 1023.0 / (max - min); // corresponds to 0--1023
    int raw_val = (int)(tmp + 0.5); // For rounding
    if (raw_val > 1023) raw_val = 1023; // Do not exceed max value
    set_pwm1_raw(raw_val);
}

// Functions for CCP2 (RC5 heater control)
void set_pwm2_raw(unsigned int raw_value) // raw value 0 -- 1023 corresponds to 0--100%
{
    CCPR2L = (raw_value >> 2) & 0x00FF; // Load the upper 8 bits in CCPR2
    CCP2CONbits.DC2B = raw_value & 0x0003; // First two bits in bits 4, 5 of CCP2CON
}

void set_pwm2_percent(float value) // value 0--100%, corresponds to 0--1023
{
    float tmp = value * 1023.0 / 100.0; // Scale 0--100 to 0--1023
    int raw_val = (int)(tmp + 0.5); // For rounding
    if (raw_val > 1023) raw_val = 1023; // Do not exceed max value
    set_pwm2_raw(raw_val);
}

void set_pwm2_voltage(float value) // value 0--5V, corresponds to 0--1023
{
    float tmp = value * 1023.0 / 5.0; // Scale 0--5 to 0--1023
    int raw_val = (int)(tmp + 0.5); // For rounding
    if (raw_val > 1023) raw_val = 1023; // Do not exceed max value
    set_pwm2_raw(raw_val);
}

// General function for CCP2 (RC5) with adjustable range
void set_pwm2_general(float value, float min, float max) // value range from min to max
{
    float tmp = (value - min) * 1023.0 / (max - min); // corresponds to 0--1023
    int raw_val = (int)(tmp + 0.5); // For rounding
    if (raw_val > 1023) raw_val = 1023; // Do not exceed max value
    set_pwm2_raw(raw_val);
}
