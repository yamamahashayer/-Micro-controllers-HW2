#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#define _XTAL_FREQ 4000000UL 
#include <xc.h> // Include processor files - each processor file is guarded.

// Function declarations for PWM on RC2 (CCP1) and RC5 (CCP2)
void init_pwm1(void); // Initializes PWM for CCP1 (RC2) - 10-bit accuracy
void init_pwm2(void); // Initializes PWM for CCP2 (RC5) - 10-bit accuracy
void set_pwm1_raw(unsigned int raw_value); // Set raw value for CCP1 (0 -- 1023)
void set_pwm1_percent(float value); // Set percentage for CCP1 (0--100%)
void set_pwm1_voltage(float value); // Set voltage for CCP1 (0--5V)
void set_pwm1_general(float value, float min, float max); // General set for CCP1

void set_pwm2_raw(unsigned int raw_value); // Set raw value for CCP2 (0 -- 1023)
void set_pwm2_percent(float value); // Set percentage for CCP2 (0--100%)
void set_pwm2_voltage(float value); // Set voltage for CCP2 (0--5V)
void set_pwm2_general(float value, float min, float max); // General set for CCP2

#endif	/* XC_HEADER_TEMPLATE_H */
